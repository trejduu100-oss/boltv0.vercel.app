"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Code2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useImageUpload } from "@/hooks/useImageUpload"
import { useVideoUpload } from "@/hooks/useVideoUpload"
import { useCodeGenerator } from "@/hooks/useCodeGenerator"
import { useVideoGenerator } from "@/hooks/useVideoGenerator"
import { useTextGenerator } from "@/hooks/useTextGenerator"
import { ImageUploadZone } from "@/components/ImageUploadZone"
import { VideoUploadZone } from "@/components/VideoUploadZone"
import { TextInputZone } from "@/components/TextInputZone"
import { MediaTypeSelector } from "@/components/MediaTypeSelector"
import { PatternControls } from "@/components/PatternControls"
import { GenerationControls } from "@/components/GenerationControls"
import { OutputDisplay } from "@/components/OutputDisplay"
import { VideoOutputDisplay } from "@/components/VideoOutputDisplay"
import { TextOutputDisplay } from "@/components/TextOutputDisplay"
import { PatternExamples } from "@/components/PatternExamples"
import type { ColorScheme, OutputFormat, MediaType } from "@/types"

export default function ImageCodeConverter() {
  const [mediaType, setMediaType] = useState<MediaType>("image")
  const [colorScheme, setColorScheme] = useState<ColorScheme>("original")
  const [outputFormat, setOutputFormat] = useState<OutputFormat>("binary")
  const [fontSize, setFontSize] = useState([8])
  const [density, setDensity] = useState([10])
  const [inputText, setInputText] = useState("") // Added text input state

  const { toast } = useToast()
  const imageUpload = useImageUpload()
  const videoUpload = useVideoUpload()
  const codeGenerator = useCodeGenerator()
  const videoGenerator = useVideoGenerator()
  const textGenerator = useTextGenerator() // Added text generator hook

  const handleGenerate = () => {
    const options = {
      colorScheme,
      outputFormat,
      fontSize: fontSize[0],
      density: density[0],
    }

    if (mediaType === "image") {
      if (!imageUpload.uploadedImage) return

      codeGenerator.generateCodeImage(
        imageUpload.uploadedImage,
        options,
        (message) => toast({ title: "Code Pattern Generated!", description: message }),
        (message) => toast({ title: "Error", description: message, variant: "destructive" }),
      )
    } else if (mediaType === "video") {
      if (videoUpload.videoFrames.length === 0) return

      videoGenerator.generateVideoFrames(
        videoUpload.videoFrames,
        options,
        (message) => toast({ title: "Video Generated!", description: message }),
        (message) => toast({ title: "Error", description: message, variant: "destructive" }),
      )
    } else if (mediaType === "text") {
      textGenerator.generatePattern(
        inputText,
        outputFormat,
        colorScheme,
        (message) => toast({ title: "Text Pattern Generated!", description: message }),
        (message) => toast({ title: "Error", description: message, variant: "destructive" }),
      )
    }
  }

  const handleDownload = () => {
    if (mediaType === "image") {
      const filename = `code-pattern-${outputFormat}-${colorScheme}.png`
      codeGenerator.downloadImage(filename)
    } else if (mediaType === "video") {
      const filename = `code-pattern-video-${outputFormat}-${colorScheme}.zip`
      videoGenerator.downloadVideo(filename, 10)
    } else if (mediaType === "text") {
      const filename = `text-pattern-${outputFormat}.txt`
      const blob = new Blob([textGenerator.generatedText], { type: "text/plain" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = filename
      a.click()
      URL.revokeObjectURL(url)
    }
  }

  const canGenerate =
    mediaType === "image"
      ? !!imageUpload.uploadedImage
      : mediaType === "video"
        ? videoUpload.videoFrames.length > 0
        : inputText.trim().length > 0

  const hasGenerated =
    mediaType === "image"
      ? !!codeGenerator.generatedImageUrl
      : mediaType === "video"
        ? videoGenerator.generatedFrames.length > 0
        : !!textGenerator.generatedText

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-500 via-purple-500 to-green-400 bg-clip-text text-transparent">
            Image, Video & Text to Code Pattern Generator
          </h1>
          <p className="text-gray-400">
            Transform images, videos, and text into visual code patterns with binary, hex, ASCII and more
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Upload Section */}
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-400">
                <Upload className="w-5 h-5" />
                {mediaType === "text" ? "Text Input" : "Media Upload"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <MediaTypeSelector mediaType={mediaType} onMediaTypeChange={setMediaType} />

              {mediaType === "image" ? (
                <ImageUploadZone
                  uploadedImage={imageUpload.uploadedImage}
                  isDragging={imageUpload.isDragging}
                  onDragOver={imageUpload.handleDragOver}
                  onDragLeave={imageUpload.handleDragLeave}
                  onDrop={imageUpload.handleDrop}
                  onFileSelect={imageUpload.handleFileSelect}
                />
              ) : mediaType === "video" ? (
                <VideoUploadZone
                  uploadedVideo={videoUpload.uploadedVideo}
                  videoFrames={videoUpload.videoFrames}
                  selectedFrame={videoUpload.selectedFrame}
                  isExtractingFrames={videoUpload.isExtractingFrames}
                  isDragging={videoUpload.isDragging}
                  onDragOver={videoUpload.handleDragOver}
                  onDragLeave={videoUpload.handleDragLeave}
                  onDrop={videoUpload.handleDrop}
                  onFileSelect={videoUpload.handleFileSelect}
                  onExtractFrames={() => videoUpload.extractFrames(1, 10)}
                  onFrameSelect={videoUpload.setSelectedFrame}
                />
              ) : (
                <TextInputZone onTextChange={setInputText} />
              )}

              <PatternControls
                colorScheme={colorScheme}
                outputFormat={outputFormat}
                fontSize={fontSize}
                density={density}
                onColorSchemeChange={setColorScheme}
                onOutputFormatChange={setOutputFormat}
                onFontSizeChange={setFontSize}
                onDensityChange={setDensity}
              />

              <GenerationControls
                canGenerate={canGenerate}
                isGenerating={
                  mediaType === "image"
                    ? codeGenerator.isGenerating
                    : mediaType === "video"
                      ? videoGenerator.isGenerating
                      : textGenerator.isGenerating
                }
                hasGenerated={hasGenerated}
                onGenerate={handleGenerate}
                onRegenerate={handleGenerate}
              />
            </CardContent>
          </Card>

          {/* Generated Output */}
          <Card className="lg:col-span-2 bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-400">
                <Code2 className="w-5 h-5" />
                Generated Code Pattern {mediaType === "video" && "(Animated)"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {mediaType === "image" ? (
                <OutputDisplay
                  generatedImageUrl={codeGenerator.generatedImageUrl}
                  generatedText={codeGenerator.generatedText}
                  onDownload={handleDownload}
                />
              ) : mediaType === "video" ? (
                <VideoOutputDisplay
                  generatedFrames={videoGenerator.generatedFrames}
                  generatedTexts={videoGenerator.generatedTexts}
                  currentFrameIndex={videoGenerator.currentFrameIndex}
                  isGenerating={videoGenerator.isGenerating}
                  generationProgress={videoGenerator.generationProgress}
                  isAnimating={videoGenerator.isAnimating}
                  onToggleAnimation={videoGenerator.toggleAnimation}
                  onDownload={handleDownload}
                />
              ) : (
                <TextOutputDisplay generatedText={textGenerator.generatedText} onDownload={handleDownload} />
              )}
            </CardContent>
          </Card>
        </div>

        <PatternExamples />

        {/* Hidden Canvases */}
        <canvas ref={codeGenerator.canvasRef} className="hidden" width={800} height={600} />
        <canvas ref={videoGenerator.canvasRef} className="hidden" width={800} height={600} />
      </div>
    </div>
  )
}
