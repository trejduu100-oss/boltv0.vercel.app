"use client"

import type React from "react"
import { useState, useCallback } from "react"
import { VideoFrameExtractor } from "@/utils/videoFrameExtractor"
import type { VideoFrame } from "@/types"

export function useVideoUpload() {
  const [uploadedVideo, setUploadedVideo] = useState<string | null>(null)
  const [videoFrames, setVideoFrames] = useState<VideoFrame[]>([])
  const [selectedFrame, setSelectedFrame] = useState<VideoFrame | null>(null)
  const [isExtractingFrames, setIsExtractingFrames] = useState(false)
  const [isDragging, setIsDragging] = useState(false)

  const processVideo = useCallback(async (videoDataUrl: string) => {
    setUploadedVideo(videoDataUrl)
    setIsExtractingFrames(true)
    try {
      const extractor = new VideoFrameExtractor()
      const frames = await extractor.extractFrames(videoDataUrl, 1, 10)
      setVideoFrames(frames)
      if (frames.length > 0) {
        setSelectedFrame(frames[0])
      }
      extractor.cleanup()
    } catch (error) {
      console.error("[v0] Error extracting frames:", error)
    } finally {
      setIsExtractingFrames(false)
    }
  }, [])

  const handleDragOver = useCallback((evt: React.DragEvent) => {
    evt.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((evt: React.DragEvent) => {
    evt.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(
    (evt: React.DragEvent) => {
      evt.preventDefault()
      setIsDragging(false)

      const files = Array.from(evt.dataTransfer.files)
      const videoFile = files.find((file) => file.type.startsWith("video/"))

      if (videoFile) {
        const reader = new FileReader()
        reader.onload = (evt) => {
          const result = (evt.target as FileReader | null)?.result as string | null
          if (result) processVideo(result)
        }
        reader.readAsDataURL(videoFile)
      }
    },
    [processVideo],
  )

  const handleFileSelect = useCallback(
    (evt: React.ChangeEvent<HTMLInputElement>) => {
      const file = evt.target.files?.[0]
      if (file && file.type.startsWith("video/")) {
        const reader = new FileReader()
        reader.onload = (evt) => {
          const result = (evt.target as FileReader | null)?.result as string | null
          if (result) processVideo(result)
        }
        reader.readAsDataURL(file)
      }
    },
    [processVideo],
  )

  const extractFrames = useCallback(
    async (frameInterval = 1, maxFrames = 10) => {
      if (!uploadedVideo) return

      setIsExtractingFrames(true)
      try {
        const extractor = new VideoFrameExtractor()
        const frames = await extractor.extractFrames(uploadedVideo, frameInterval, maxFrames)
        setVideoFrames(frames)
        if (frames.length > 0) {
          setSelectedFrame(frames[0])
        }
        extractor.cleanup()
      } catch (error) {
        console.error("[v0] Error extracting frames:", error)
      } finally {
        setIsExtractingFrames(false)
      }
    },
    [uploadedVideo],
  )

  const clearVideo = useCallback(() => {
    setUploadedVideo(null)
    setVideoFrames([])
    setSelectedFrame(null)
  }, [])

  return {
    uploadedVideo,
    videoFrames,
    selectedFrame,
    isExtractingFrames,
    isDragging,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    handleFileSelect,
    extractFrames,
    setSelectedFrame,
    clearVideo,
  }
}
