"use client"

import { useState } from "react"
import { generateTextPattern, getPatternCharacters } from "@/utils/textToPattern"
import type { ColorScheme, OutputFormat } from "@/types"

export function useTextGenerator() {
  const [generatedText, setGeneratedText] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(false)

  const generatePattern = (
    inputText: string,
    outputFormat: OutputFormat,
    colorScheme: ColorScheme,
    onSuccess?: (message: string) => void,
    onError?: (message: string) => void,
  ) => {
    if (!inputText.trim()) {
      onError?.("Please enter some text to convert")
      return
    }

    setIsGenerating(true)

    try {
      const patternChars = getPatternCharacters(outputFormat)
      const pattern = generateTextPattern({
        text: inputText,
        pattern: patternChars,
        colorScheme,
      })

      setGeneratedText(pattern)
      onSuccess?.("Text pattern generated successfully!")
    } catch (error) {
      console.error("[v0] Error generating text pattern:", error)
      onError?.("Failed to generate text pattern")
    } finally {
      setIsGenerating(false)
    }
  }

  const reset = () => {
    setGeneratedText("")
  }

  return {
    generatedText,
    isGenerating,
    generatePattern,
    reset,
  }
}
