export type ColorScheme = "original" | "blackwhite" | "hacker" | "matrix"
export type OutputFormat =
  | "binary"
  | "hash"
  | "hex"
  | "ascii"
  | "blocks"
  | "braille"
  | "emoji"
  | "math"
  | "boxdraw"
  | "arrows"
  | "roman"
  | "greek"
  | "kanji"
  | "cards"
  | "music"
  | "zodiac"
  | "weather"
  | "shapes"
  | "currency"
  | "punctuation"
  | "geometric"
  | "circles"
  | "triangles"
  | "squares"
  | "dots"
  | "lines"
  | "corners"
  | "faces"
  | "hands"
  | "hearts"
  | "stars"
  | "flowers"
  | "food"
  | "animals"
  | "circlednums"
  | "dice"
  | "chess"

export type MediaType = "image" | "video" | "text" // Added "text" media type

export interface ImageProcessingOptions {
  colorScheme: ColorScheme
  outputFormat: OutputFormat
  fontSize: number
  density: number
}

export interface GeneratedImage {
  url: string
  format: OutputFormat
  colorScheme: ColorScheme
}

export interface VideoFrame {
  url: string
  timestamp: number
  index: number
}

export interface VideoProcessingOptions extends ImageProcessingOptions {
  frameInterval: number // Extract frame every N seconds
  maxFrames: number // Maximum number of frames to extract
}
