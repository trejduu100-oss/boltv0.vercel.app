"use client"

import { Button } from "@/components/ui/button"
import { ImageIcon, VideoIcon, Type } from "lucide-react"
import type { MediaType } from "@/types"

interface MediaTypeSelectorProps {
  mediaType: MediaType
  onMediaTypeChange: (type: MediaType) => void
}

export function MediaTypeSelector({ mediaType, onMediaTypeChange }: MediaTypeSelectorProps) {
  return (
    <div className="flex gap-2 p-1 bg-gray-800 rounded-lg">
      <Button
        onClick={() => onMediaTypeChange("image")}
        variant={mediaType === "image" ? "default" : "ghost"}
        className={`flex-1 ${
          mediaType === "image"
            ? "bg-orange-600 hover:bg-orange-700 text-white"
            : "text-gray-400 hover:text-white hover:bg-gray-700"
        }`}
      >
        <ImageIcon className="w-4 h-4 mr-2" />
        Image
      </Button>
      <Button
        onClick={() => onMediaTypeChange("video")}
        variant={mediaType === "video" ? "default" : "ghost"}
        className={`flex-1 ${
          mediaType === "video"
            ? "bg-purple-600 hover:bg-purple-700 text-white"
            : "text-gray-400 hover:text-white hover:bg-gray-700"
        }`}
      >
        <VideoIcon className="w-4 h-4 mr-2" />
        Video
      </Button>
      <Button
        onClick={() => onMediaTypeChange("text")}
        variant={mediaType === "text" ? "default" : "ghost"}
        className={`flex-1 ${
          mediaType === "text"
            ? "bg-green-600 hover:bg-green-700 text-white"
            : "text-gray-400 hover:text-white hover:bg-gray-700"
        }`}
      >
        <Type className="w-4 h-4 mr-2" />
        Text
      </Button>
    </div>
  )
}
