"use client"

import type React from "react"

import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Type } from "lucide-react"

interface TextInputZoneProps {
  onTextChange: (text: string) => void
}

export function TextInputZone({ onTextChange }: TextInputZoneProps) {
  const [text, setText] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value
    setText(newText)
    onTextChange(newText)
  }

  return (
    <div className="space-y-3">
      <Label htmlFor="text-input" className="text-sm font-medium flex items-center gap-2">
        <Type className="w-4 h-4" />
        Enter Text to Convert
      </Label>
      <Textarea
        id="text-input"
        value={text}
        onChange={handleChange}
        placeholder="Type your text here... (e.g., HELLO WORLD)"
        className="min-h-[120px] bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 font-mono resize-none"
        maxLength={50}
      />
      <p className="text-xs text-gray-500">{text.length}/50 characters • Best results with uppercase letters</p>
    </div>
  )
}
