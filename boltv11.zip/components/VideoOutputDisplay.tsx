"use client"

import { Button } from "@/components/ui/button"
import { Code2, Download, Play, Pause, Copy } from "lucide-react"
import Image from "next/image"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"

interface VideoOutputDisplayProps {
  generatedFrames: string[]
  generatedTexts: string[]
  currentFrameIndex: number
  isGenerating: boolean
  generationProgress: number
  isAnimating: boolean
  onToggleAnimation: () => void
  onDownload: () => void
}

export function VideoOutputDisplay({
  generatedFrames,
  generatedTexts,
  currentFrameIndex,
  isGenerating,
  generationProgress,
  isAnimating,
  onToggleAnimation,
  onDownload,
}: VideoOutputDisplayProps) {
  const { toast } = useToast()

  const handleCopyText = async () => {
    const currentText = generatedTexts[currentFrameIndex]
    if (!currentText) return

    try {
      await navigator.clipboard.writeText(currentText)
      toast({
        title: "Copied!",
        description: `Frame ${currentFrameIndex + 1} code pattern copied to clipboard`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  if (isGenerating) {
    return (
      <div className="min-h-[400px] flex items-center justify-center border-2 border-dashed border-gray-600 rounded-lg">
        <div className="text-center space-y-4 w-full max-w-md px-4">
          <Code2 className="w-16 h-16 mx-auto text-orange-500 animate-pulse" />
          <p className="text-gray-400">Generating video frames...</p>
          <Progress value={generationProgress} className="w-full" />
          <p className="text-sm text-gray-500">{Math.round(generationProgress)}% complete</p>
        </div>
      </div>
    )
  }

  if (generatedFrames.length === 0) {
    return (
      <div className="min-h-[400px] flex items-center justify-center border-2 border-dashed border-gray-600 rounded-lg">
        <div className="text-center space-y-2">
          <Code2 className="w-16 h-16 mx-auto text-gray-500" />
          <p className="text-gray-400">Upload a video and generate to see animated code pattern</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <div className="flex gap-2 mb-4">
        <Button onClick={onToggleAnimation} className="bg-purple-600 hover:bg-purple-700 text-white">
          {isAnimating ? (
            <>
              <Pause className="w-4 h-4 mr-2" />
              Pause
            </>
          ) : (
            <>
              <Play className="w-4 h-4 mr-2" />
              Play
            </>
          )}
        </Button>
        <Button onClick={handleCopyText} className="bg-blue-600 hover:bg-blue-700 text-white">
          <Copy className="w-4 h-4 mr-2" />
          Copy Text
        </Button>
        <Button onClick={onDownload} className="bg-orange-600 hover:bg-orange-700 text-white">
          <Download className="w-4 h-4 mr-2" />
          Download Frames (ZIP)
        </Button>
      </div>
      <div className="border border-gray-700 rounded-lg p-4 bg-black">
        <div className="mb-2 text-sm text-gray-400 text-center">
          Frame {currentFrameIndex + 1} of {generatedFrames.length}
        </div>
        <Image
          src={generatedFrames[currentFrameIndex] || "/placeholder.svg"}
          alt={`Generated Code Pattern Frame ${currentFrameIndex + 1}`}
          width={800}
          height={600}
          className="max-w-full h-auto mx-auto rounded"
        />
      </div>
    </>
  )
}
