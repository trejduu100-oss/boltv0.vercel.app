"use client"

import type React from "react"
import { Badge } from "@/components/ui/badge"
import { VideoIcon, Film } from "lucide-react"
import Image from "next/image"
import type { VideoFrame } from "@/types"

interface VideoUploadZoneProps {
  uploadedVideo: string | null
  videoFrames: VideoFrame[]
  selectedFrame: VideoFrame | null
  isExtractingFrames: boolean
  isDragging: boolean
  onDragOver: (evt: React.DragEvent) => void
  onDragLeave: (evt: React.DragEvent) => void
  onDrop: (evt: React.DragEvent) => void
  onFileSelect: (evt: React.ChangeEvent<HTMLInputElement>) => void
  onExtractFrames: () => void
  onFrameSelect: (frame: VideoFrame) => void
}

export function VideoUploadZone({
  uploadedVideo,
  videoFrames,
  selectedFrame,
  isExtractingFrames,
  isDragging,
  onDragOver,
  onDragLeave,
  onDrop,
  onFileSelect,
  onFrameSelect,
}: VideoUploadZoneProps) {
  return (
    <div className="space-y-4">
      <div
        className={`relative border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
          isDragging ? "border-purple-500 bg-purple-500/10" : "border-gray-600 hover:border-purple-500/50"
        }`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
      >
        {uploadedVideo ? (
          <div className="space-y-4">
            <video src={uploadedVideo} className="mx-auto rounded-lg max-w-full h-auto max-h-48" controls />
            {isExtractingFrames ? (
              <div className="flex items-center justify-center gap-2 text-purple-400">
                <Film className="w-4 h-4 animate-pulse" />
                <span className="text-sm">Extracting frames automatically...</span>
              </div>
            ) : (
              <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">
                Video Loaded - {videoFrames.length} frames extracted
              </Badge>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <VideoIcon className="w-12 h-12 mx-auto text-gray-500" />
            <div>
              <p className="font-medium">Drop video here</p>
              <p className="text-sm text-gray-400">or click to browse (MP4, WebM, MOV)</p>
            </div>
          </div>
        )}
        <input
          type="file"
          accept="video/*"
          onChange={onFileSelect}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
      </div>

      {videoFrames.length > 0 && (
        <div className="space-y-2">
          <label className="text-sm font-medium text-purple-400">
            Select Frame to Generate ({videoFrames.length} available)
          </label>
          <div className="grid grid-cols-5 gap-2 max-h-48 overflow-y-auto p-2 bg-gray-800/50 rounded-lg">
            {videoFrames.map((frame) => (
              <button
                key={frame.index}
                onClick={() => onFrameSelect(frame)}
                className={`relative aspect-video rounded overflow-hidden border-2 transition-all hover:scale-105 ${
                  selectedFrame?.index === frame.index
                    ? "border-purple-500 ring-2 ring-purple-500/50"
                    : "border-gray-600"
                }`}
              >
                <Image
                  src={frame.url || "/placeholder.svg"}
                  alt={`Frame ${frame.index}`}
                  fill
                  className="object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-xs text-white px-1 py-0.5">
                  {frame.timestamp.toFixed(1)}s
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
