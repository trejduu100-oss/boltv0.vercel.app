"use client"

import { Button } from "@/components/ui/button"
import { Copy, Download } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface TextOutputDisplayProps {
  generatedText: string
  onDownload: () => void
}

export function TextOutputDisplay({ generatedText, onDownload }: TextOutputDisplayProps) {
  const { toast } = useToast()

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(generatedText)
      toast({
        title: "Copied!",
        description: "Text pattern copied to clipboard",
      })
    } catch (error) {
      console.error("[v0] Failed to copy:", error)
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  if (!generatedText) {
    return (
      <div className="flex items-center justify-center h-[400px] bg-gray-800 rounded-lg border-2 border-dashed border-gray-700">
        <div className="text-center space-y-2">
          <p className="text-gray-400">Your generated text pattern will appear here</p>
          <p className="text-sm text-gray-500">Enter text and click Generate to start</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="bg-gray-950 rounded-lg p-6 border border-gray-800 overflow-x-auto">
        <pre className="text-orange-400 font-mono text-sm leading-tight whitespace-pre">{generatedText}</pre>
      </div>

      <div className="flex gap-2">
        <Button onClick={handleCopy} className="flex-1 bg-blue-600 hover:bg-blue-700">
          <Copy className="w-4 h-4 mr-2" />
          Copy Text
        </Button>
        <Button onClick={onDownload} className="flex-1 bg-green-600 hover:bg-green-700">
          <Download className="w-4 h-4 mr-2" />
          Download .txt
        </Button>
      </div>
    </div>
  )
}
