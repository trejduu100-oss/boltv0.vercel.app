"use client"

import { Button } from "@/components/ui/button"
import { Code2, Download, Copy } from "lucide-react"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast"

interface OutputDisplayProps {
  generatedImageUrl: string | null
  generatedText: string | null
  onDownload: () => void
}

export function OutputDisplay({ generatedImageUrl, generatedText, onDownload }: OutputDisplayProps) {
  const { toast } = useToast()

  const handleCopyText = async () => {
    if (!generatedText) return

    try {
      await navigator.clipboard.writeText(generatedText)
      toast({
        title: "Copied!",
        description: "Code pattern copied to clipboard",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  if (!generatedImageUrl) {
    return (
      <div className="min-h-[400px] flex items-center justify-center border-2 border-dashed border-gray-600 rounded-lg">
        <div className="text-center space-y-2">
          <Code2 className="w-16 h-16 mx-auto text-gray-500" />
          <p className="text-gray-400">Upload an image and generate to see code pattern</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <div className="flex gap-2 mb-4">
        <Button onClick={handleCopyText} className="bg-blue-600 hover:bg-blue-700 text-white">
          <Copy className="w-4 h-4 mr-2" />
          Copy Text
        </Button>
        <Button onClick={onDownload} className="bg-orange-600 hover:bg-orange-700 text-white">
          <Download className="w-4 h-4 mr-2" />
          Download PNG
        </Button>
      </div>
      <div className="border border-gray-700 rounded-lg p-4 bg-black">
        <Image
          src={generatedImageUrl || "/placeholder.svg"}
          alt="Generated Code Pattern"
          width={800}
          height={600}
          className="max-w-full h-auto mx-auto rounded"
        />
      </div>
    </>
  )
}
