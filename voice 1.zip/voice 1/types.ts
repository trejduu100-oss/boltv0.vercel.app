
export interface VoiceOption {
  id: string;
  name: string;
  avatar: string;
}
