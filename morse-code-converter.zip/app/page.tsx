"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import MorseConverter from "@/components/morse-converter"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-foreground">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">·−</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Morse Code</h1>
              <p className="text-sm text-slate-400">Text to Morse Converter</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Info */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <h2 className="text-lg font-semibold text-white mb-4">About Morse Code</h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                Morse code is a method of transmitting text information as a series of on-off tones, lights, or clicks.
              </p>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <h3 className="text-sm font-semibold text-cyan-400 mb-3">Key Features</h3>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-1">•</span>
                  <span>Real-time conversion</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-1">•</span>
                  <span>Copy to clipboard</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-1">•</span>
                  <span>Audio playback</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-1">•</span>
                  <span>Supports letters & numbers</span>
                </li>
              </ul>
            </Card>
          </div>

          {/* Right Column - Converter */}
          <div className="lg:col-span-2">
            <MorseConverter />
          </div>
        </div>

        <div className="mt-16 pt-12 border-t border-slate-700">
          <Card className="bg-slate-800/50 border-slate-700 p-8">
            <h2 className="text-2xl font-bold text-white mb-6">How to Run Locally</h2>

            <div className="space-y-6 text-slate-300">
              <div>
                <h3 className="text-lg font-semibold text-cyan-400 mb-3">Prerequisites</h3>
                <ul className="space-y-2 text-sm ml-4">
                  <li>• Node.js 18+ installed</li>
                  <li>• npm or yarn package manager</li>
                  <li>• Git (optional, for cloning)</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-cyan-400 mb-3">Installation Steps</h3>
                <div className="space-y-4 text-sm">
                  <div className="bg-slate-900 border border-slate-600 rounded-lg p-4 font-mono">
                    <p className="text-slate-400 mb-2"># 1. Clone or download the project</p>
                    <p className="text-cyan-400">git clone &lt;repository-url&gt;</p>
                    <p className="text-cyan-400">cd morse-code-converter</p>
                  </div>

                  <div className="bg-slate-900 border border-slate-600 rounded-lg p-4 font-mono">
                    <p className="text-slate-400 mb-2"># 2. Install dependencies</p>
                    <p className="text-cyan-400">npm install</p>
                  </div>

                  <div className="bg-slate-900 border border-slate-600 rounded-lg p-4 font-mono">
                    <p className="text-slate-400 mb-2"># 3. Run the development server</p>
                    <p className="text-cyan-400">npm run dev</p>
                  </div>

                  <div className="bg-slate-900 border border-slate-600 rounded-lg p-4 font-mono">
                    <p className="text-slate-400 mb-2"># 4. Open in your browser</p>
                    <p className="text-cyan-400">http://localhost:3000</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-cyan-400 mb-3">Available Commands</h3>
                <div className="space-y-2 text-sm">
                  <div className="bg-slate-900 border border-slate-600 rounded-lg p-3 font-mono">
                    <p>
                      <span className="text-cyan-400">npm run dev</span>{" "}
                      <span className="text-slate-400">- Start development server</span>
                    </p>
                  </div>
                  <div className="bg-slate-900 border border-slate-600 rounded-lg p-3 font-mono">
                    <p>
                      <span className="text-cyan-400">npm run build</span>{" "}
                      <span className="text-slate-400">- Build for production</span>
                    </p>
                  </div>
                  <div className="bg-slate-900 border border-slate-600 rounded-lg p-3 font-mono">
                    <p>
                      <span className="text-cyan-400">npm start</span>{" "}
                      <span className="text-slate-400">- Start production server</span>
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-cyan-400 mb-3">Troubleshooting</h3>
                <ul className="space-y-2 text-sm ml-4">
                  <li>
                    • <span className="text-cyan-400">Port 3000 already in use?</span> Run{" "}
                    <span className="font-mono text-slate-400">npm run dev -- -p 3001</span>
                  </li>
                  <li>
                    • <span className="text-cyan-400">Dependencies not installing?</span> Try{" "}
                    <span className="font-mono text-slate-400">npm install --legacy-peer-deps</span>
                  </li>
                  <li>
                    • <span className="text-cyan-400">Audio not working?</span> Check browser console for errors and
                    ensure audio is enabled
                  </li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 mt-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-center text-sm text-slate-400">Built with Next.js • Morse Code Converter © 2025</p>
        </div>
      </footer>
    </main>
  )
}
