"use client"

import type React from "react"
import type { AudioBufferSourceNode } from "standardized-audio-context"
import { useState, useCallback, useRef } from "react"
import { Copy, Volume2, RotateCcw, Square, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"

const MORSE_CODE_DICT: Record<string, string> = {
  A: "·−",
  B: "−···",
  C: "−·−·",
  D: "−··",
  E: "·",
  F: "··−·",
  G: "−−·",
  H: "····",
  I: "··",
  J: "·−−−",
  K: "−·−",
  L: "·−··",
  M: "−−",
  N: "−·",
  O: "−−−",
  P: "·−−·",
  Q: "−−·−",
  R: "·−·",
  S: "···",
  T: "−",
  U: "··−",
  V: "···−",
  W: "·−−",
  X: "−··−",
  Y: "−·−−",
  Z: "−−··",
  "0": "−−−−−",
  "1": "·−−−−",
  "2": "··−−−",
  "3": "···−−",
  "4": "····−",
  "5": "·····",
  "6": "−····",
  "7": "−−···",
  "8": "−−−··",
  "9": "−−−−·",
  ".": "·−·−·−",
  ",": "−−··−−",
  "?": "··−−··",
  "'": "·−−−−·",
  "!": "−·−·−",
  "/": "−··−·",
  "(": "−·−−·",
  ")": "−·−−·−",
  "&": "·−···",
  ":": "−−−···",
  ";": "−·−·−·",
  "=": "−···−",
  "+": "·−·−·",
  "−": "−····−",
  _: "··−−·−",
  '"': "·−··−·",
  $: "···−··−",
  "@": "·−−·−·",
  " ": "/",
}

const MORSE_TO_TEXT: Record<string, string> = Object.entries(MORSE_CODE_DICT).reduce(
  (acc, [key, value]) => ({ ...acc, [value]: key }),
  {},
)

function audioBufferToWav(audioBuffer: AudioBuffer): Blob {
  const numberOfChannels = audioBuffer.numberOfChannels
  const sampleRate = audioBuffer.sampleRate
  const format = 1 // PCM
  const bitDepth = 16

  const bytesPerSample = bitDepth / 8
  const blockAlign = numberOfChannels * bytesPerSample

  const offset = 0
  const pos = 0

  const setUint16 = (data: DataView, pos: number, value: number) => {
    data.setUint16(pos, value, true)
  }

  const setUint32 = (data: DataView, pos: number, value: number) => {
    data.setUint32(pos, value, true)
  }

  const encodeWAV = (samples: Float32Array, mono: boolean) => {
    const dataLength = samples.length * bytesPerSample
    const bufferLength = 36 + dataLength
    const arrayBuffer = new ArrayBuffer(44 + dataLength)
    const view = new DataView(arrayBuffer)

    setUint32(view, 0, 0x46464952) // "RIFF"
    setUint32(view, 4, bufferLength)
    setUint32(view, 8, 0x45564157) // "WAVE"
    setUint32(view, 12, 0x20746d66) // "fmt "
    setUint32(view, 16, 16) // chunk size
    setUint16(view, 20, format)
    setUint16(view, 22, numberOfChannels)
    setUint32(view, 24, sampleRate)
    setUint32(view, 28, sampleRate * blockAlign)
    setUint16(view, 32, blockAlign)
    setUint16(view, 34, bitDepth)
    setUint32(view, 36, 0x61746164) // "data"
    setUint32(view, 40, dataLength)

    let index = 44
    const volume = 0.8
    for (let i = 0; i < samples.length; i++) {
      const sample = Math.max(-1, Math.min(1, samples[i]))
      view.setInt16(index, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true)
      index += 2
    }

    return new Blob([arrayBuffer], { type: "audio/wav" })
  }

  const channels: Float32Array[] = []
  for (let i = 0; i < numberOfChannels; i++) {
    channels.push(audioBuffer.getChannelData(i))
  }

  if (numberOfChannels === 2) {
    const interleaved = new Float32Array(audioBuffer.length * 2)
    let index = 0
    for (let i = 0; i < audioBuffer.length; i++) {
      interleaved[index++] = channels[0][i]
      interleaved[index++] = channels[1][i]
    }
    return encodeWAV(interleaved, false)
  }

  return encodeWAV(channels[0], true)
}

export default function MorseConverter() {
  const [text, setText] = useState("")
  const [morse, setMorse] = useState("")
  const [isPlaying, setIsPlaying] = useState(false)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const oscillatorsRef = useRef<OscillatorNode[]>([])
  const bufferSourceRef = useRef<AudioBufferSourceNode | null>(null)
  const { toast } = useToast()

  const textToMorse = useCallback((input: string) => {
    return input
      .toUpperCase()
      .split("")
      .map((char) => MORSE_CODE_DICT[char] || char)
      .join(" ")
  }, [])

  const morseToText = useCallback((input: string) => {
    return input
      .split(" ")
      .map((code) => MORSE_TO_TEXT[code] || code)
      .join("")
  }, [])

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value
    setText(newText)
    setMorse(textToMorse(newText))
  }

  const handleMorseChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newMorse = e.target.value
    setMorse(newMorse)
    setText(morseToText(newMorse))
  }

  const handleCopyText = () => {
    navigator.clipboard.writeText(text)
    toast({ description: "Text copied to clipboard!" })
  }

  const handleCopyMorse = () => {
    navigator.clipboard.writeText(morse)
    toast({ description: "Morse code copied to clipboard!" })
  }

  const handlePlayAudio = async () => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    audioContextRef.current = audioContext
    oscillatorsRef.current = []
    setIsPlaying(true)

    const dotDuration = 0.1
    const dashDuration = 0.3
    const gapDuration = 0.1
    const letterGapDuration = 0.3
    const frequency = 800

    let currentTime = 0

    morse.split(" ").forEach((code) => {
      code.split("").forEach((symbol) => {
        const duration = symbol === "·" ? dotDuration : dashDuration
        currentTime += duration + gapDuration
      })
      currentTime += letterGapDuration
    })

    const totalDuration = currentTime
    const sampleRate = audioContext.sampleRate
    const offlineContext = new OfflineAudioContext(1, sampleRate * totalDuration, sampleRate)

    currentTime = 0

    morse.split(" ").forEach((code) => {
      code.split("").forEach((symbol) => {
        const oscillator = offlineContext.createOscillator()
        const gainNode = offlineContext.createGain()

        oscillator.connect(gainNode)
        gainNode.connect(offlineContext.destination)
        oscillator.frequency.value = frequency

        const duration = symbol === "·" ? dotDuration : dashDuration
        oscillator.start(currentTime)
        oscillator.stop(currentTime + duration)
        gainNode.gain.setValueAtTime(0.3, currentTime)
        gainNode.gain.setValueAtTime(0, currentTime + duration)

        oscillatorsRef.current.push(oscillator)
        currentTime += duration + gapDuration
      })
      currentTime += letterGapDuration
    })

    try {
      const audioBuffer = await offlineContext.startRendering()
      const wavBlob = audioBufferToWav(audioBuffer)
      setAudioBlob(wavBlob)
      toast({ description: "Audio ready for download!" })

      const source = audioContext.createBufferSource()
      source.buffer = audioBuffer
      source.connect(audioContext.destination)
      bufferSourceRef.current = source
      source.start(0)

      setTimeout(() => {
        setIsPlaying(false)
      }, totalDuration * 1000)
    } catch (error) {
      console.error("Error rendering audio:", error)
      toast({ description: "Error generating audio", variant: "destructive" })
      setIsPlaying(false)
    }
  }

  const handleStopAudio = () => {
    if (bufferSourceRef.current) {
      try {
        bufferSourceRef.current.stop()
      } catch (e) {
        // Source already stopped
      }
      bufferSourceRef.current = null
    }
    setIsPlaying(false)
  }

  const handleDownloadAudio = () => {
    if (audioBlob) {
      const url = URL.createObjectURL(audioBlob)
      const a = document.createElement("a")
      a.href = url
      a.download = `morse-code-${Date.now()}.wav`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      toast({ description: "Audio downloaded!" })
    }
  }

  const handleReset = () => {
    setText("")
    setMorse("")
    setAudioBlob(null)
  }

  return (
    <div className="space-y-6">
      {/* Text Input */}
      <Card className="bg-slate-800/50 border-slate-700 p-6">
        <label className="block text-sm font-semibold text-white mb-3">Text Input</label>
        <textarea
          value={text}
          onChange={handleTextChange}
          placeholder="Enter text to convert..."
          className="w-full bg-slate-900 border border-slate-600 text-white placeholder:text-slate-500 mb-3 rounded-md p-3 font-sans resize-vertical min-h-24"
        />
        <Button
          onClick={handleCopyText}
          variant="outline"
          size="sm"
          className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
        >
          <Copy className="w-4 h-4 mr-2" />
          Copy Text
        </Button>
      </Card>

      {/* Morse Output */}
      <Card className="bg-slate-800/50 border-slate-700 p-6">
        <label className="block text-sm font-semibold text-white mb-3">Morse Code Output</label>
        <div className="bg-slate-900 border border-slate-600 rounded-lg p-4 mb-3 min-h-24 font-mono text-cyan-400 break-words overflow-y-auto max-h-48">
          {morse || <span className="text-slate-500">Morse code will appear here...</span>}
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            onClick={handleCopyMorse}
            variant="outline"
            size="sm"
            className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
          >
            <Copy className="w-4 h-4 mr-2" />
            Copy Morse
          </Button>
          <Button
            onClick={handlePlayAudio}
            disabled={!morse || isPlaying}
            variant="outline"
            size="sm"
            className="border-slate-600 text-slate-300 hover:bg-slate-700 disabled:opacity-50 bg-transparent"
          >
            <Volume2 className="w-4 h-4 mr-2" />
            Play Audio
          </Button>
          <Button
            onClick={handleStopAudio}
            disabled={!isPlaying}
            variant="outline"
            size="sm"
            className="border-red-600 text-red-400 hover:bg-red-950 disabled:opacity-50 bg-transparent"
          >
            <Square className="w-4 h-4 mr-2" />
            Stop
          </Button>
          <Button
            onClick={handleDownloadAudio}
            disabled={!audioBlob}
            variant="outline"
            size="sm"
            className="border-green-600 text-green-400 hover:bg-green-950 disabled:opacity-50 bg-transparent"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Audio
          </Button>
        </div>
      </Card>

      {/* Morse Input (Reverse) */}
      <Card className="bg-slate-800/50 border-slate-700 p-6">
        <label className="block text-sm font-semibold text-white mb-3">Morse Code Input (Reverse)</label>
        <textarea
          value={morse}
          onChange={handleMorseChange}
          placeholder="Enter morse code (use · and −)..."
          className="w-full bg-slate-900 border border-slate-600 text-white placeholder:text-slate-500 mb-3 rounded-md p-3 font-mono resize-vertical min-h-24"
        />
        <p className="text-xs text-slate-400">Use · (dot) and − (dash) separated by spaces</p>
      </Card>

      {/* Reset Button */}
      <Button
        onClick={handleReset}
        className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
      >
        <RotateCcw className="w-4 h-4 mr-2" />
        Reset All
      </Button>

      {/* Reference */}
      <Card className="bg-slate-800/50 border-slate-700 p-6">
        <h3 className="text-sm font-semibold text-white mb-4">Quick Reference</h3>
        <div className="grid grid-cols-2 gap-3 text-xs text-slate-300">
          <div>
            <p className="text-cyan-400 font-mono mb-2">· = Dot (short)</p>
            <p className="text-cyan-400 font-mono">− = Dash (long)</p>
          </div>
          <div>
            <p className="text-slate-400">A = ·−</p>
            <p className="text-slate-400">B = −···</p>
            <p className="text-slate-400">C = −·−·</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
