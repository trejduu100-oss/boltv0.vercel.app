# 🎨 Image & Video to Code Pattern Converter

*Transform your images and videos into stunning visual code art with customizable patterns and themes*

[![Deployed on Vercel](https://img.shields.io/badge/Deployed%20on-Vercel-black?style=for-the-badge&logo=vercel)](https://vercel.com/mshaheerzs-projects/v0-custom-ui-theme-creator)
[![Built with v0](https://img.shields.io/badge/Built%20with-v0.dev-black?style=for-the-badge)](https://v0.dev/chat/projects/IBHIME72cUp)

## 🚀 Overview

The **Image & Video to Code Pattern Converter** is a modern web application that transforms your uploaded images and video frames into visually stunning code-pattern artwork. Built with a sleek black, orange, and purple theme, this tool converts media into various code representations like binary patterns, ASCII art, hex displays, and more.

## ✨ Features

### 🎯 Core Functionality
- **Drag & Drop Upload**: Intuitive image and video uploading with visual feedback
- **Video Frame Extraction**: Extract frames from videos at configurable intervals
- **Frame Selection**: Choose specific frames from extracted video thumbnails
- **Multiple Pattern Types**: 
  - Binary (`0101010101`)
  - Hash symbols (`###*+=-`)
  - Hex values (`A1B2C3D4E5F6`)
  - ASCII art (` .:-=+*%#@`)
  - Block characters (`█▓▒░`)
  - Braille dots (`⠿⠇⠃⠁`)
  - Emoji patterns (`🌑🌘🌗🌕⭐`)
  - Math symbols (`∑∫π∞√`)
  - Box drawing (`┼├┤┬┴`)
  - Arrows (`→←↑↓⇒⇔`)

### 🎨 Customization Options
- **Color Schemes**:
  - Original colors
  - Monochrome (Black & White)
  - Hacker Green
  - Matrix style
- **Pattern Controls**:
  - Adjustable font size (4-16px)
  - Density control (5-20)
  - Real-time pattern preview

### 🖼️ Output Features
- **Visual Code Images**: Generated as downloadable PNG files
- **High Quality**: Canvas-based rendering for crisp output
- **Instant Preview**: See results before downloading
- **Pattern Examples**: Visual guides for each pattern type

## 🛠️ Technology Stack

- **Frontend**: Next.js 14 with App Router
- **UI Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS + shadcn/ui components
- **Canvas Rendering**: HTML5 Canvas API
- **Video Processing**: HTML5 Video API with frame extraction
- **State Management**: Custom React hooks
- **File Handling**: Native File API with drag & drop

## 🏗️ Architecture

### Component Structure
\`\`\`
components/
├── ImageUploadZone.tsx     # Drag & drop image upload interface
├── VideoUploadZone.tsx     # Video upload with frame extraction
├── MediaTypeSelector.tsx   # Switch between image/video modes
├── PatternControls.tsx     # Settings and configuration
├── GenerationControls.tsx  # Action buttons
├── OutputDisplay.tsx       # Result visualization
├── VideoOutputDisplay.tsx  # Video result visualization
└── PatternExamples.tsx     # Static pattern previews

hooks/
├── useImageUpload.ts       # Image upload logic
├── useVideoUpload.ts       # Video upload and frame extraction
├── useCodeGenerator.ts     # Pattern generation logic
└── useVideoGenerator.ts    # Video pattern generation logic

utils/
├── codePatternGenerator.ts # Canvas rendering engine
└── videoFrameExtractor.ts  # Video frame extraction utility

types/
└── index.ts               # TypeScript definitions
\`\`\`

### Key Design Patterns
- **Separation of Concerns**: Business logic separated from UI components
- **Custom Hooks**: Reusable state management
- **Type Safety**: Comprehensive TypeScript interfaces
- **Error Handling**: Robust error boundaries and user feedback

## 🚀 Getting Started

### Prerequisites

Before you begin, ensure you have the following installed on your system:

- **Node.js**: Version 18.17 or higher (LTS recommended)
  - Check your version: `node --version`
  - Download from [nodejs.org](https://nodejs.org/)
- **Package Manager**: npm (comes with Node.js), yarn, or pnpm
  - npm: `npm --version`
  - yarn: `yarn --version`
  - pnpm: `pnpm --version`

### Installation

Follow these steps to set up the project locally:

#### 1. Clone the Repository

\`\`\`bash
# Using HTTPS
git clone https://github.com/your-username/image-to-code-pattern.git

# Or using SSH
git clone git@github.com:your-username/image-to-code-pattern.git

# Navigate to the project directory
cd image-to-code-pattern
\`\`\`

#### 2. Install Dependencies

Choose your preferred package manager:

\`\`\`bash
# Using npm
npm install

# Using yarn
yarn install

# Using pnpm
pnpm install
\`\`\`

This will install all required dependencies including:
- Next.js 15
- React 19
- TypeScript
- Tailwind CSS
- shadcn/ui components
- Lucide React icons

#### 3. Run the Development Server

Start the local development server:

\`\`\`bash
# Using npm
npm run dev

# Using yarn
yarn dev

# Using pnpm
pnpm dev
\`\`\`

The application will be available at:
- **Local**: [http://localhost:3000](http://localhost:3000)
- **Network**: Your local IP address (shown in terminal)

#### 4. Build for Production (Optional)

To create an optimized production build:

\`\`\`bash
# Build the application
npm run build

# Start the production server
npm run start
\`\`\`

### Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server with hot reload |
| `npm run build` | Create optimized production build |
| `npm run start` | Run production server (requires build first) |
| `npm run lint` | Run ESLint to check code quality |
| `npm run type-check` | Run TypeScript compiler check |

### Project Structure

\`\`\`
image-to-code-pattern/
├── app/                    # Next.js App Router
│   ├── layout.tsx         # Root layout with fonts
│   ├── page.tsx           # Main application page
│   └── globals.css        # Global styles and theme
├── components/            # React components
│   ├── ui/               # shadcn/ui components
│   ├── ImageUploadZone.tsx
│   ├── VideoUploadZone.tsx
│   ├── MediaTypeSelector.tsx
│   ├── PatternControls.tsx
│   ├── GenerationControls.tsx
│   ├── OutputDisplay.tsx
│   ├── VideoOutputDisplay.tsx
│   └── PatternExamples.tsx
├── hooks/                 # Custom React hooks
│   ├── useImageUpload.ts
│   ├── useVideoUpload.ts
│   ├── useCodeGenerator.ts
│   └── useVideoGenerator.ts
├── utils/                 # Utility functions
│   ├── codePatternGenerator.ts
│   └── videoFrameExtractor.ts
├── types/                 # TypeScript type definitions
│   └── index.ts
├── public/               # Static assets
├── package.json          # Dependencies and scripts
├── tsconfig.json         # TypeScript configuration
├── tailwind.config.ts    # Tailwind CSS configuration
└── next.config.mjs       # Next.js configuration
\`\`\`

### Troubleshooting

#### Port Already in Use

If port 3000 is already in use:

\`\`\`bash
# Use a different port
PORT=3001 npm run dev
\`\`\`

#### Module Not Found Errors

If you encounter module errors after cloning:

\`\`\`bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
\`\`\`

#### TypeScript Errors

If you see TypeScript errors:

\`\`\`bash
# Run type checking
npm run type-check

# Clear Next.js cache
rm -rf .next
npm run dev
\`\`\`

#### Canvas Rendering Issues

If generated images appear blank:
- Ensure your browser supports HTML5 Canvas
- Check browser console for CORS errors
- Try a different image format (PNG, JPG, WebP)

#### Video Upload Not Working

If video upload fails:
- Verify the video format is supported (MP4, WebM, MOV)
- Check video file size (large files may take longer to process)
- Ensure browser supports HTML5 Video API

### Browser Compatibility

This application works best on modern browsers:
- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Opera 76+

### Performance Tips

For optimal performance:
- Use images under 5MB for faster processing
- Keep video files under 50MB
- Reduce density setting for large images
- Use smaller font sizes for detailed patterns

## 🎨 Pattern Types Explained

| Pattern | Description | Example |
|---------|-------------|---------|
| **Binary** | Uses 0s and 1s based on pixel brightness | `01010101` |
| **Hash** | Symbols representing different intensities | `###*+=-` |
| **Hex** | Hexadecimal color codes and values | `A1B2C3` |
| **ASCII** | Classic ASCII art characters | ` .:-=+*` |
| **Blocks** | Unicode block characters | `█▓▒░` |
| **Braille** | Braille Unicode dot patterns | `⠿⠇⠃⠁` |
| **Emoji** | Moon phases and star emojis | `🌑🌕⭐✨` |
| **Math** | Mathematical symbols | `∑∫π∞√` |
| **Box Drawing** | Line art characters | `┼├┤┬┴` |
| **Arrows** | Directional arrow symbols | `→←↑↓⇒` |

## 🔮 Future Enhancements

### 🎬 Video Features
- [x] **Video Upload**: Support for MP4, WebM, and MOV formats
- [x] **Frame Extraction**: Extract frames at configurable intervals
- [x] **Frame Selection**: Visual thumbnail grid for frame selection
- [ ] **Batch Frame Processing**: Generate patterns for all frames at once
- [ ] **Animated GIF Output**: Create animated code patterns from video frames
- [ ] **Video Timeline Scrubber**: Precise frame selection with timeline control
- [ ] **Frame Rate Control**: Adjust extraction frame rate

### 🎬 Animation Features
- [ ] **Animated GIF Output**: Create animated code patterns with scrolling effects
- [ ] **Blinking Patterns**: Add terminal-style blinking cursors
- [ ] **Typewriter Effect**: Simulate code being typed in real-time

### 🎨 Advanced Patterns
- [ ] **JSON Structure**: Convert images to JSON-like visual patterns
- [ ] **XML/HTML Tags**: Create markup-style visual representations
- [ ] **CSS Properties**: Generate CSS-inspired pattern layouts
- [ ] **JavaScript Syntax**: Code patterns mimicking JS structure

### 🚀 Enhanced Functionality
- [ ] **Batch Processing**: Upload and process multiple images simultaneously
- [ ] **Social Sharing**: Direct sharing to social media platforms
- [ ] **Pattern Presets**: Pre-configured popular code aesthetics
- [ ] **Custom Fonts**: Support for different monospace fonts
- [ ] **Vector Output**: SVG generation for scalable patterns

### 🎯 User Experience
- [ ] **Pattern Gallery**: Showcase of community-generated patterns
- [ ] **Save Configurations**: Remember user preferences
- [ ] **Keyboard Shortcuts**: Power user navigation
- [ ] **Mobile Optimization**: Enhanced mobile experience
- [ ] **Accessibility**: Screen reader and keyboard navigation support

### 🔧 Technical Improvements
- [ ] **WebGL Rendering**: Hardware-accelerated pattern generation
- [ ] **Worker Threads**: Background processing for large images
- [ ] **Progressive Web App**: Offline functionality
- [ ] **API Integration**: RESTful API for programmatic access
- [ ] **Plugin System**: Extensible pattern generation

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

### Development Setup
\`\`\`bash
# Fork the repository
# Clone your fork
git clone https://github.com/your-username/image-to-code-pattern.git

# Create a feature branch
git checkout -b feature/amazing-feature

# Make your changes
# Commit and push
git commit -m 'Add amazing feature'
git push origin feature/amazing-feature

# Open a Pull Request
\`\`\`

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- UI components from [shadcn/ui](https://ui.shadcn.com/)
- Icons from [Lucide React](https://lucide.dev/)
- Deployed on [Vercel](https://vercel.com/)

## 📞 Support

- 🐛 **Bug Reports**: [Open an issue](https://github.com/your-username/image-to-code-pattern/issues)
- 💡 **Feature Requests**: [Start a discussion](https://github.com/your-username/image-to-code-pattern/discussions)
- 📧 **Contact**: [Your Email](mailto:your-email@example.com)

## 🚀 Deployment to Vercel

This application is optimized for deployment on [Vercel](https://vercel.com/), the platform built by the creators of Next.js.

### Method 1: Deploy via Vercel Dashboard (Recommended)

This is the easiest way to deploy your application:

#### Step 1: Push to GitHub

First, push your code to a GitHub repository:

\`\`\`bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit your changes
git commit -m "Initial commit"

# Add your GitHub repository as remote
git remote add origin https://github.com/your-username/image-to-code-pattern.git

# Push to GitHub
git push -u origin main
\`\`\`

#### Step 2: Import to Vercel

1. Go to [vercel.com](https://vercel.com/) and sign in with your GitHub account
2. Click **"Add New..."** → **"Project"**
3. Import your GitHub repository
4. Vercel will automatically detect Next.js and configure the build settings
5. Click **"Deploy"**

That's it! Vercel will build and deploy your application automatically.

#### Step 3: Access Your Deployment

Once deployed, you'll receive:
- **Production URL**: `https://your-project-name.vercel.app`
- **Deployment Dashboard**: Monitor builds and analytics
- **Automatic HTTPS**: SSL certificate included

### Method 2: Deploy via Vercel CLI

For developers who prefer the command line:

#### Step 1: Install Vercel CLI

\`\`\`bash
# Install globally
npm install -g vercel

# Or use with npx (no installation needed)
npx vercel
\`\`\`

#### Step 2: Login to Vercel

\`\`\`bash
vercel login
\`\`\`

Follow the prompts to authenticate with your Vercel account.

#### Step 3: Deploy

\`\`\`bash
# Deploy to preview (staging)
vercel

# Deploy to production
vercel --prod
\`\`\`

The CLI will guide you through:
- Project setup
- Build configuration
- Deployment process

#### Step 4: View Deployment

\`\`\`bash
# Open deployment in browser
vercel --prod --open
\`\`\`

### Method 3: One-Click Deploy

Click the button below to deploy directly to Vercel:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/image-to-code-pattern)

This will:
1. Fork the repository to your GitHub account
2. Create a new Vercel project
3. Deploy automatically

### Deployment Configuration

#### Build Settings

Vercel automatically detects these settings for Next.js:

| Setting | Value |
|---------|-------|
| **Framework Preset** | Next.js |
| **Build Command** | `npm run build` |
| **Output Directory** | `.next` |
| **Install Command** | `npm install` |
| **Development Command** | `npm run dev` |

#### Environment Variables

If your project requires environment variables:

1. Go to your project in Vercel Dashboard
2. Navigate to **Settings** → **Environment Variables**
3. Add your variables:
   - `NEXT_PUBLIC_API_URL` (if using external APIs)
   - `NEXT_PUBLIC_ANALYTICS_ID` (if using analytics)
   - Any other custom variables

**Note**: Variables prefixed with `NEXT_PUBLIC_` are exposed to the browser.

#### Custom Domain

To add a custom domain:

1. Go to your project in Vercel Dashboard
2. Navigate to **Settings** → **Domains**
3. Add your domain (e.g., `myapp.com`)
4. Follow DNS configuration instructions
5. Vercel automatically provisions SSL certificate

### Continuous Deployment

Once connected to GitHub, Vercel automatically:

- **Deploys on Push**: Every push to `main` branch deploys to production
- **Preview Deployments**: Pull requests get unique preview URLs
- **Instant Rollbacks**: Revert to any previous deployment instantly
- **Branch Deployments**: Deploy specific branches for testing

### Deployment Best Practices

#### 1. Optimize Before Deploying

\`\`\`bash
# Run production build locally to test
npm run build
npm run start

# Check for TypeScript errors
npm run type-check

# Run linting
npm run lint
\`\`\`

#### 2. Monitor Build Logs

- Check Vercel Dashboard for build logs
- Look for warnings or errors during build
- Verify all dependencies are installed correctly

#### 3. Test Preview Deployments

- Always test preview deployments before merging to production
- Share preview URLs with team for review
- Verify functionality on preview environment

#### 4. Performance Optimization

Vercel automatically optimizes:
- Image optimization via Next.js Image component
- Automatic code splitting
- Edge caching for static assets
- Gzip/Brotli compression

### Troubleshooting Deployment

#### Build Fails

If your build fails on Vercel:

\`\`\`bash
# Test build locally first
npm run build

# Check Node.js version matches
node --version

# Clear cache and rebuild
rm -rf .next node_modules
npm install
npm run build
\`\`\`

#### Environment Variables Not Working

- Ensure variables are prefixed with `NEXT_PUBLIC_` for client-side access
- Redeploy after adding new environment variables
- Check variable names match exactly (case-sensitive)

#### 404 Errors After Deployment

- Verify all routes are properly defined in `app/` directory
- Check `next.config.mjs` for any custom routing
- Ensure dynamic routes use correct file naming (`[id]/page.tsx`)

#### Slow Build Times

To speed up builds:
- Enable Vercel's build cache (automatic)
- Optimize dependencies (remove unused packages)
- Use `output: 'standalone'` in `next.config.mjs` for smaller builds

### Vercel Features

Your deployed application includes:

- **Analytics**: Built-in Web Analytics and Speed Insights
- **Edge Network**: Global CDN for fast content delivery
- **Serverless Functions**: API routes run as serverless functions
- **Automatic Scaling**: Handles traffic spikes automatically
- **DDoS Protection**: Built-in security features
- **Zero Configuration**: Works out of the box

### Monitoring Your Deployment

Access deployment metrics:

1. **Analytics**: View page views, unique visitors, and top pages
2. **Speed Insights**: Monitor Core Web Vitals and performance
3. **Logs**: Real-time function logs and errors
4. **Deployments**: History of all deployments with rollback option

### Cost Considerations

Vercel offers:
- **Hobby Plan**: Free for personal projects
  - Unlimited deployments
  - 100GB bandwidth per month
  - Automatic HTTPS
  - Preview deployments
- **Pro Plan**: For professional use
  - Higher limits
  - Team collaboration
  - Advanced analytics
  - Priority support

For most personal projects, the free Hobby plan is sufficient.

### Additional Resources

- [Vercel Documentation](https://vercel.com/docs)
- [Next.js Deployment Guide](https://nextjs.org/docs/deployment)
- [Vercel CLI Reference](https://vercel.com/docs/cli)
- [Custom Domains Guide](https://vercel.com/docs/concepts/projects/custom-domains)

---

<div align="center">
  <p>Made with ❤️ and lots of ☕</p>
  <p>Transform your images and videos into code art today!</p>
</div>
