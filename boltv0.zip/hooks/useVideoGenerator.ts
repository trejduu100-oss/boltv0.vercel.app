"use client"

import { useState, useCallback, useRef } from "react"
import type { ImageProcessingOptions, VideoFrame } from "@/types"
import { CodePatternGenerator } from "@/utils/codePatternGenerator"

export function useVideoGenerator() {
  const [generatedFrames, setGeneratedFrames] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationProgress, setGenerationProgress] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const [currentFrameIndex, setCurrentFrameIndex] = useState(0)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number | null>(null)

  const generateVideoFrames = useCallback(
    async (
      videoFrames: VideoFrame[],
      options: ImageProcessingOptions,
      onSuccess: (message: string) => void,
      onError: (message: string) => void,
    ) => {
      if (!videoFrames.length || !canvasRef.current) return

      setIsGenerating(true)
      setGenerationProgress(0)
      const frames: string[] = []

      try {
        const generator = new CodePatternGenerator(canvasRef.current)

        for (let i = 0; i < videoFrames.length; i++) {
          const frame = videoFrames[i]
          const imageUrl = await generator.generate(frame.url, options)
          frames.push(imageUrl)
          setGenerationProgress(((i + 1) / videoFrames.length) * 100)
        }

        setGeneratedFrames(frames)
        setCurrentFrameIndex(0)
        onSuccess(`Generated ${frames.length} animated frames from your video!`)
      } catch (error) {
        console.error("[v0] Error generating video frames:", error)
        onError("Failed to generate video frames. Please try again.")
      } finally {
        setIsGenerating(false)
      }
    },
    [],
  )

  const startAnimation = useCallback(() => {
    if (generatedFrames.length === 0) return

    setIsAnimating(true)
    let frameIndex = 0

    const animate = () => {
      setCurrentFrameIndex(frameIndex)
      frameIndex = (frameIndex + 1) % generatedFrames.length
      animationRef.current = requestAnimationFrame(animate)
    }

    // Start at ~30 FPS
    const fps = 30
    const frameDelay = 1000 / fps

    const intervalId = setInterval(() => {
      setCurrentFrameIndex((prev) => (prev + 1) % generatedFrames.length)
    }, frameDelay)

    return () => clearInterval(intervalId)
  }, [generatedFrames])

  const stopAnimation = useCallback(() => {
    setIsAnimating(false)
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
  }, [])

  const toggleAnimation = useCallback(() => {
    if (isAnimating) {
      stopAnimation()
    } else {
      startAnimation()
    }
  }, [isAnimating, startAnimation, stopAnimation])

  const downloadVideo = useCallback(
    async (filename: string, fps = 10) => {
      if (generatedFrames.length === 0 || !canvasRef.current) return

      // Create a zip file with all frames
      const JSZip = (await import("jszip")).default
      const zip = new JSZip()

      generatedFrames.forEach((frameUrl, index) => {
        const base64Data = frameUrl.split(",")[1]
        zip.file(`frame_${String(index).padStart(4, "0")}.png`, base64Data, { base64: true })
      })

      // Add a README with instructions
      const readme = `Video Code Pattern Frames
Generated: ${new Date().toISOString()}
Total Frames: ${generatedFrames.length}
Recommended FPS: ${fps}

To create a video from these frames, you can use ffmpeg:
ffmpeg -framerate ${fps} -i frame_%04d.png -c:v libx264 -pix_fmt yuv420p output.mp4
`
      zip.file("README.txt", readme)

      const blob = await zip.generateAsync({ type: "blob" })
      const link = document.createElement("a")
      link.href = URL.createObjectURL(blob)
      link.download = filename
      link.click()
      URL.revokeObjectURL(link.href)
    },
    [generatedFrames],
  )

  const clearGenerated = useCallback(() => {
    stopAnimation()
    setGeneratedFrames([])
    setCurrentFrameIndex(0)
    setGenerationProgress(0)
  }, [stopAnimation])

  return {
    generatedFrames,
    currentFrameIndex,
    isGenerating,
    generationProgress,
    isAnimating,
    canvasRef,
    generateVideoFrames,
    toggleAnimation,
    downloadVideo,
    clearGenerated,
  }
}
