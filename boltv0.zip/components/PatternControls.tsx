"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import type { ColorScheme, OutputFormat } from "@/types"

interface PatternControlsProps {
  colorScheme: ColorScheme
  outputFormat: OutputFormat
  fontSize: number[]
  density: number[]
  onColorSchemeChange: (value: ColorScheme) => void
  onOutputFormatChange: (value: OutputFormat) => void
  onFontSizeChange: (value: number[]) => void
  onDensityChange: (value: number[]) => void
}

export function PatternControls({
  colorScheme,
  outputFormat,
  fontSize,
  density,
  onColorSchemeChange,
  onOutputFormatChange,
  onFontSizeChange,
  onDensityChange,
}: PatternControlsProps) {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium text-orange-400">Pattern Type</label>
        <Select value={outputFormat} onValueChange={onOutputFormatChange}>
          <SelectTrigger className="bg-gray-800 border-gray-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-700 max-h-[400px]">
            <div className="px-2 py-1.5 text-xs font-semibold text-orange-400">Classic Patterns</div>
            <SelectItem value="binary">🔢 Binary (0,1)</SelectItem>
            <SelectItem value="hash">⚡ Hash (#,*,+)</SelectItem>
            <SelectItem value="hex">🎯 Hex (0-F)</SelectItem>
            <SelectItem value="ascii">📝 ASCII Art</SelectItem>
            <SelectItem value="blocks">⬛ Block Chars</SelectItem>

            <div className="px-2 py-1.5 text-xs font-semibold text-orange-400 mt-2">Unicode & Symbols</div>
            <SelectItem value="braille">⠿ Braille Dots</SelectItem>
            <SelectItem value="emoji">😊 Emoji</SelectItem>
            <SelectItem value="math">∑ Math Symbols</SelectItem>
            <SelectItem value="boxdraw">┼ Box Drawing</SelectItem>
            <SelectItem value="arrows">→ Arrows</SelectItem>

            <div className="px-2 py-1.5 text-xs font-semibold text-orange-400 mt-2">Language & Text</div>
            <SelectItem value="roman">Ⅰ Roman Numerals</SelectItem>
            <SelectItem value="greek">α Greek Letters</SelectItem>
            <SelectItem value="kanji">日 Kanji</SelectItem>
            <SelectItem value="punctuation">!? Punctuation</SelectItem>

            <div className="px-2 py-1.5 text-xs font-semibold text-orange-400 mt-2">Shapes & Geometry</div>
            <SelectItem value="shapes">○ Shapes</SelectItem>
            <SelectItem value="geometric">◢ Geometric</SelectItem>
            <SelectItem value="circles">◉ Circles</SelectItem>
            <SelectItem value="triangles">▲ Triangles</SelectItem>
            <SelectItem value="squares">■ Squares</SelectItem>
            <SelectItem value="dots">• Dots</SelectItem>
            <SelectItem value="lines">─ Lines</SelectItem>
            <SelectItem value="corners">┌ Corners</SelectItem>

            <div className="px-2 py-1.5 text-xs font-semibold text-orange-400 mt-2">Fun & Decorative</div>
            <SelectItem value="faces">☺ Faces</SelectItem>
            <SelectItem value="hands">👆 Hands</SelectItem>
            <SelectItem value="hearts">♥ Hearts</SelectItem>
            <SelectItem value="stars">★ Stars</SelectItem>
            <SelectItem value="flowers">✿ Flowers</SelectItem>
            <SelectItem value="food">🍕 Food</SelectItem>
            <SelectItem value="animals">🐶 Animals</SelectItem>

            <div className="px-2 py-1.5 text-xs font-semibold text-orange-400 mt-2">Special Symbols</div>
            <SelectItem value="cards">♠ Playing Cards</SelectItem>
            <SelectItem value="music">♪ Music Notes</SelectItem>
            <SelectItem value="zodiac">♈ Zodiac Signs</SelectItem>
            <SelectItem value="weather">☀ Weather</SelectItem>
            <SelectItem value="currency">$ Currency</SelectItem>
            <SelectItem value="circlednums">① Circled Numbers</SelectItem>
            <SelectItem value="dice">⚀ Dice</SelectItem>
            <SelectItem value="chess">♔ Chess Pieces</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-orange-400">Color Scheme</label>
        <Select value={colorScheme} onValueChange={onColorSchemeChange}>
          <SelectTrigger className="bg-gray-800 border-gray-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-700">
            <SelectItem value="original">🎨 Original</SelectItem>
            <SelectItem value="blackwhite">⚫ Monochrome</SelectItem>
            <SelectItem value="hacker">💚 Hacker Green</SelectItem>
            <SelectItem value="matrix">🟢 Matrix Style</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-orange-400">Font Size: {fontSize[0]}px</label>
        <Slider value={fontSize} onValueChange={onFontSizeChange} max={16} min={4} step={1} className="w-full" />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-orange-400">Density: {density[0]}</label>
        <Slider value={density} onValueChange={onDensityChange} max={20} min={5} step={1} className="w-full" />
      </div>
    </div>
  )
}
