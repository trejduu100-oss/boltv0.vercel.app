import type { VideoFrame } from "@/types"

export class VideoFrameExtractor {
  private video: HTMLVideoElement
  private canvas: HTMLCanvasElement
  private ctx: CanvasRenderingContext2D

  constructor() {
    this.video = document.createElement("video")
    this.canvas = document.createElement("canvas")
    const context = this.canvas.getContext("2d")
    if (!context) {
      throw new Error("Canvas context not available")
    }
    this.ctx = context
    this.video.crossOrigin = "anonymous"
  }

  async extractFrames(videoUrl: string, frameInterval = 1, maxFrames = 10): Promise<VideoFrame[]> {
    return new Promise((resolve, reject) => {
      this.video.src = videoUrl
      this.video.load()

      this.video.addEventListener("loadedmetadata", async () => {
        try {
          const duration = this.video.duration
          const frames: VideoFrame[] = []
          const totalFrames = Math.min(maxFrames, Math.floor(duration / frameInterval))

          for (let i = 0; i < totalFrames; i++) {
            const timestamp = i * frameInterval
            const frameUrl = await this.captureFrameAtTime(timestamp)
            frames.push({
              url: frameUrl,
              timestamp,
              index: i,
            })
          }

          resolve(frames)
        } catch (error) {
          reject(error)
        }
      })

      this.video.addEventListener("error", () => {
        reject(new Error("Failed to load video"))
      })
    })
  }

  private captureFrameAtTime(timestamp: number): Promise<string> {
    return new Promise((resolve, reject) => {
      this.video.currentTime = timestamp

      const onSeeked = () => {
        try {
          this.canvas.width = this.video.videoWidth
          this.canvas.height = this.video.videoHeight
          this.ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height)

          this.canvas.toBlob((blob) => {
            if (blob) {
              const url = URL.createObjectURL(blob)
              resolve(url)
            } else {
              reject(new Error("Failed to create frame blob"))
            }
          }, "image/png")
        } catch (error) {
          reject(error)
        } finally {
          this.video.removeEventListener("seeked", onSeeked)
        }
      }

      this.video.addEventListener("seeked", onSeeked)
    })
  }

  cleanup(): void {
    this.video.src = ""
    this.video.load()
  }
}
